import java.util.Scanner;

import com.student.manage.Student;
import com.student.manage.StudentDao;

public class Start {

	public static void main(String[] args) {
		System.out.println("Welcome to Student Management App");
		Scanner sc=new Scanner(System.in);
		
		while(true) {
			System.out.println("Press 1 to ADD Student");
			System.out.println("Press 2 to DELETE Student");
			System.out.println("Press 3 to DISPLAY Student");
			System.out.println("Press 4 to EXIT Student");
			int c=sc.nextInt();
			if(c==1) 
			{
				System.out.println("Enter user id: ");
				int id=sc.nextInt();
				
				System.out.println("Enter user name: ");
				String name=sc.next();
				
				System.out.println("Enter user phone number: ");
				int num=sc.nextInt();
				
				System.out.println("Enter user city: ");
				String city=sc.next();
				
				//create student object to store student
				Student st=new Student(id,name,num,city);
				boolean ans=StudentDao.insertStudenttoDB(st);
				if(ans) {
					System.out.println("student is added successfully");
				}
				else {
					System.out.println("something went wrong");
				}
				System.out.println(st);
			}
			else if(c==2) 
			{
				System.out.println("enter user id to delete student");
				int user_id=sc.nextInt();
				boolean f=StudentDao.deleteStudent(user_id);
				if(f) {
					System.out.println("student is deleted successfully");
				}
				else {
					System.out.println("something went wrong");
				}
			}
			else if(c==3) 
			{
				StudentDao.showAllstudents();
			}
			else if(c==4)
			{
				//exit code
				break;
			}
			else
			{
				
			}
		}
		System.out.println("Thank you for using my application...see u soon bye bye");

	}

}
