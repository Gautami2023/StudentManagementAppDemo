package com.student.manage;

public class Student {
	private int sid;
	private String sname;
	private int sphone;
	private String scity;
	public Student(int sid, String sname, int sphone, String scity) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.sphone = sphone;
		this.scity = scity;
	}
	public Student(String sname, int sphone, String scity) {
		super();
		this.sname = sname;
		this.sphone = sphone;
		this.scity = scity;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the sid
	 */
	public int getSid() {
		return sid;
	}
	/**
	 * @param sid the sid to set
	 */
	public void setSid(int sid) {
		this.sid = sid;
	}
	/**
	 * @return the sname
	 */
	public String getSname() {
		return sname;
	}
	/**
	 * @param sname the sname to set
	 */
	public void setSname(String sname) {
		this.sname = sname;
	}
	/**
	 * @return the sphone
	 */
	public int getSphone() {
		return sphone;
	}
	/**
	 * @param sphone the sphone to set
	 */
	public void setSphone(int sphone) {
		this.sphone = sphone;
	}
	/**
	 * @return the scity
	 */
	public String getScity() {
		return scity;
	}
	/**
	 * @param scity the scity to set
	 */
	public void setScity(String scity) {
		this.scity = scity;
	}
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", sphone=" + sphone + ", scity=" + scity + "]";
	}
	
}
