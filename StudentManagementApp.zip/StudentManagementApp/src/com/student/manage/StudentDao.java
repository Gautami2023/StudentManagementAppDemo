package com.student.manage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Set;

public class StudentDao {
	public static boolean insertStudenttoDB(Student st) {
		boolean flag=false;
		try {
			Connection con=CP.createC();
			String q="insert into students(sid,sname,sphone,scity) values(?,?,?,?)";
			PreparedStatement pst=con.prepareStatement(q);
			pst.setInt(1, st.getSid());
			pst.setString(2,st.getSname());
			pst.setInt(3, st.getSphone());
			pst.setString(4, st.getScity());
			pst.executeUpdate();
			flag=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean deleteStudent(int user_id) {
		boolean flag=false;
		try {
			Connection con=CP.createC();
			String q="delete from students where sid=?";
			PreparedStatement pst=con.prepareStatement(q);
			pst.setInt(1, user_id);
			
			pst.executeUpdate();
			flag=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
		
	}

	public static void showAllstudents() {
		try {
			Connection con=CP.createC();
			String q="select * from students";
			Statement st=con.createStatement();
			st.executeQuery(q);
			ResultSet rs=st.executeQuery(q);
			while(rs.next()) {
				int id=rs.getInt(1);
				String name=rs.getString(2);
				int phone=rs.getInt(3);
				String city=rs.getString(4);
				
				System.out.println("Id: "+id);
				System.out.println("name: "+name);
				System.out.println("phone number: "+phone);
				System.out.println("city: "+city);
				System.out.println("________________________________");
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
