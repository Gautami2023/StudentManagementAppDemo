package com.student.manage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CP {
	static Connection con;
	public static Connection createC() throws SQLException {
		//load the driver
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "Gautami", "12345");
			
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return con;
	}
}
